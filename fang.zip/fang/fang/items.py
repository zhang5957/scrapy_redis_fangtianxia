# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class XfItem(scrapy.Item):
    province = scrapy.Field()
    city_text = scrapy.Field()
    # 小区的名字
    name = scrapy.Field()
    # 价格
    price = scrapy.Field()
    # 几居室，是个列表
    rooms = scrapy.Field()
    # 面积
    area = scrapy.Field()
    district0 = scrapy.Field()
    # 地址
    address = scrapy.Field()
    # 是否在售
    sale = scrapy.Field()
    # 房天下详情页面url
    origin_url = scrapy.Field()


class EsfItem(scrapy.Item):
    province = scrapy.Field()
    city_text = scrapy.Field()
    # 小区的名字
    name = scrapy.Field()
    # 几居室，是个列表
    rooms = scrapy.Field()
    # 层
    floor = scrapy.Field()
    # 朝向
    toward = scrapy.Field()
    # 建筑面积
    area = scrapy.Field()
    # 价格
    price = scrapy.Field()
    # 初始页面
    origin_url = scrapy.Field()
    address = scrapy.Field()

